(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["bargaining/pages/goodItem/buyPeople/buyPeople"],{"287f":function(t,n,e){"use strict";e.r(n);var u=e("7ba9"),a=e("e43f");for(var r in a)"default"!==r&&function(t){e.d(n,t,(function(){return a[t]}))}(r);e("5087");var c,o=e("f0c5"),f=Object(o["a"])(a["default"],u["b"],u["c"],!1,null,"016aba00",null,!1,u["a"],c);n["default"]=f.exports},5087:function(t,n,e){"use strict";var u=e("6d95"),a=e.n(u);a.a},"6d95":function(t,n,e){},"7ba9":function(t,n,e){"use strict";var u,a=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"b",(function(){return a})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return u}))},"8cbd":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={data:function(){return{}},components:{},props:{data:{type:Object}},methods:{}};n.default=u},e43f:function(t,n,e){"use strict";e.r(n);var u=e("8cbd"),a=e.n(u);for(var r in u)"default"!==r&&function(t){e.d(n,t,(function(){return u[t]}))}(r);n["default"]=a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'bargaining/pages/goodItem/buyPeople/buyPeople-create-component',
    {
        'bargaining/pages/goodItem/buyPeople/buyPeople-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("287f"))
        })
    },
    [['bargaining/pages/goodItem/buyPeople/buyPeople-create-component']]
]);
