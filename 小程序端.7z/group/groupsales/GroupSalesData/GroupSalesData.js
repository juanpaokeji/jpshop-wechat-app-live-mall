(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["group/groupsales/GroupSalesData/GroupSalesData"],{"0362":function(t,e,n){"use strict";n.r(e);var r=n("aea5"),u=n.n(r);for(var a in r)"default"!==a&&function(t){n.d(e,t,(function(){return r[t]}))}(a);e["default"]=u.a},"2f7f":function(t,e,n){"use strict";n.r(e);var r=n("e51b"),u=n("0362");for(var a in u)"default"!==a&&function(t){n.d(e,t,(function(){return u[t]}))}(a);n("48e8");var o,c=n("f0c5"),f=Object(c["a"])(u["default"],r["b"],r["c"],!1,null,"4130b1e2",null,!1,r["a"],o);e["default"]=f.exports},"48e8":function(t,e,n){"use strict";var r=n("80e7"),u=n.n(r);u.a},"80e7":function(t,e,n){},aea5:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={data:function(){return{}},components:{},props:{total_price:{type:null},total_number:{type:Number},time:{type:String},list:{type:Array}},methods:{}};e.default=r},e51b:function(t,e,n){"use strict";var r,u=function(){var t=this,e=t.$createElement;t._self._c},a=[];n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return r}))}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'group/groupsales/GroupSalesData/GroupSalesData-create-component',
    {
        'group/groupsales/GroupSalesData/GroupSalesData-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("2f7f"))
        })
    },
    [['group/groupsales/GroupSalesData/GroupSalesData-create-component']]
]);
