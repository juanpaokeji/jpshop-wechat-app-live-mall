(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goodsItem/buypeopleDetail/BPDHeader/BPDHeader"],{1430:function(e,t,n){"use strict";n.r(t);var u=n("efd1"),r=n("d757");for(var a in r)"default"!==a&&function(e){n.d(t,e,(function(){return r[e]}))}(a);n("c6b9");var c,f=n("f0c5"),o=Object(f["a"])(r["default"],u["b"],u["c"],!1,null,"499f542f",null,!1,u["a"],c);t["default"]=o.exports},"476f":function(e,t,n){},c6b9:function(e,t,n){"use strict";var u=n("476f"),r=n.n(u);r.a},cba8:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;getApp();var u={data:function(){return{}},components:{},props:{number:{type:Number},people:{type:Number}},methods:{}};t.default=u},d757:function(e,t,n){"use strict";n.r(t);var u=n("cba8"),r=n.n(u);for(var a in u)"default"!==a&&function(e){n.d(t,e,(function(){return u[e]}))}(a);t["default"]=r.a},efd1:function(e,t,n){"use strict";var u,r=function(){var e=this,t=e.$createElement;e._self._c},a=[];n.d(t,"b",(function(){return r})),n.d(t,"c",(function(){return a})),n.d(t,"a",(function(){return u}))}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goodsItem/buypeopleDetail/BPDHeader/BPDHeader-create-component',
    {
        'pages/goodsItem/buypeopleDetail/BPDHeader/BPDHeader-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("1430"))
        })
    },
    [['pages/goodsItem/buypeopleDetail/BPDHeader/BPDHeader-create-component']]
]);
