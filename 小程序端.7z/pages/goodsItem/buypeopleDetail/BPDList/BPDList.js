(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goodsItem/buypeopleDetail/BPDList/BPDList"],{"0521":function(t,n,e){},"2a62":function(t,n,e){"use strict";var a,u=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return a}))},"2f63":function(t,n,e){"use strict";e.r(n);var a=e("b1c6"),u=e.n(a);for(var r in a)"default"!==r&&function(t){e.d(n,t,(function(){return a[t]}))}(r);n["default"]=u.a},"30bc":function(t,n,e){"use strict";var a=e("0521"),u=e.n(a);u.a},b1c6:function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;getApp();var e={data:function(){return{avatar:t.getStorageSync("user").avatar}},components:{},props:{data:{type:Array}},methods:{}};n.default=e}).call(this,e("543d")["default"])},c4b3:function(t,n,e){"use strict";e.r(n);var a=e("2a62"),u=e("2f63");for(var r in u)"default"!==r&&function(t){e.d(n,t,(function(){return u[t]}))}(r);e("30bc");var c,o=e("f0c5"),f=Object(o["a"])(u["default"],a["b"],a["c"],!1,null,"79666206",null,!1,a["a"],c);n["default"]=f.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goodsItem/buypeopleDetail/BPDList/BPDList-create-component',
    {
        'pages/goodsItem/buypeopleDetail/BPDList/BPDList-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("c4b3"))
        })
    },
    [['pages/goodsItem/buypeopleDetail/BPDList/BPDList-create-component']]
]);
