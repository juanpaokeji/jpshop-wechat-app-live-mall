(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/advertising/advertising"],{"17e5":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(t){},immediate:!0,deep:!0}},methods:{go:function(t){wx.navigateTo({url:t.currentTarget.dataset.link})}}};e.default=a},"43f9":function(t,e,n){},5778:function(t,e,n){"use strict";var a=n("43f9"),r=n.n(a);r.a},"79b8":function(t,e,n){"use strict";n.r(e);var a=n("17e5"),r=n.n(a);for(var u in a)"default"!==u&&function(t){n.d(e,t,(function(){return a[t]}))}(u);e["default"]=r.a},adee:function(t,e,n){"use strict";var a,r=function(){var t=this,e=t.$createElement;t._self._c},u=[];n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return a}))},ee42:function(t,e,n){"use strict";n.r(e);var a=n("adee"),r=n("79b8");for(var u in r)"default"!==u&&function(t){n.d(e,t,(function(){return r[t]}))}(u);n("5778");var c,i=n("f0c5"),o=Object(i["a"])(r["default"],a["b"],a["c"],!1,null,"605e75ca",null,!1,a["a"],c);e["default"]=o.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/advertising/advertising-create-component',
    {
        'pages/index/advertising/advertising-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("ee42"))
        })
    },
    [['pages/index/advertising/advertising-create-component']]
]);
