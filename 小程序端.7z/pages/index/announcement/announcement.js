(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/announcement/announcement"],{"1d37":function(n,t,e){},"2f9f":function(n,t,e){"use strict";e.r(t);var a=e("b17e"),u=e.n(a);for(var r in a)"default"!==r&&function(n){e.d(t,n,(function(){return a[n]}))}(r);t["default"]=u.a},4384:function(n,t,e){"use strict";e.r(t);var a=e("ab9d"),u=e("2f9f");for(var r in u)"default"!==r&&function(n){e.d(t,n,(function(){return u[n]}))}(r);e("ea1a");var c,o=e("f0c5"),f=Object(o["a"])(u["default"],a["b"],a["c"],!1,null,"502fc774",null,!1,a["a"],c);t["default"]=f.exports},ab9d:function(n,t,e){"use strict";var a,u=function(){var n=this,t=n.$createElement;n._self._c},r=[];e.d(t,"b",(function(){return u})),e.d(t,"c",(function(){return r})),e.d(t,"a",(function(){return a}))},b17e:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;wx.getBackgroundAudioManager();var a={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(n){},immediate:!0,deep:!0}},methods:{}};t.default=a},ea1a:function(n,t,e){"use strict";var a=e("1d37"),u=e.n(a);u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/announcement/announcement-create-component',
    {
        'pages/index/announcement/announcement-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("4384"))
        })
    },
    [['pages/index/announcement/announcement-create-component']]
]);
