(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/banner/banner"],{7637:function(n,t,e){"use strict";var u=e("772d"),a=e.n(u);a.a},"772d":function(n,t,e){},"873c":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var u={data:function(){return{style:2}},components:{},props:{data:{type:Object,observe:function(n){}}},methods:{go:function(n){wx.navigateTo({url:n.currentTarget.dataset.link})},tijiao:function(n){}}};t.default=u},"9ffd":function(n,t,e){"use strict";e.r(t);var u=e("c471"),a=e("daf8");for(var r in a)"default"!==r&&function(n){e.d(t,n,(function(){return a[n]}))}(r);e("7637");var c,o=e("f0c5"),f=Object(o["a"])(a["default"],u["b"],u["c"],!1,null,"7c2b7629",null,!1,u["a"],c);t["default"]=f.exports},c471:function(n,t,e){"use strict";var u,a=function(){var n=this,t=n.$createElement;n._self._c},r=[];e.d(t,"b",(function(){return a})),e.d(t,"c",(function(){return r})),e.d(t,"a",(function(){return u}))},daf8:function(n,t,e){"use strict";e.r(t);var u=e("873c"),a=e.n(u);for(var r in u)"default"!==r&&function(n){e.d(t,n,(function(){return u[n]}))}(r);t["default"]=a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/banner/banner-create-component',
    {
        'pages/index/banner/banner-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("9ffd"))
        })
    },
    [['pages/index/banner/banner-create-component']]
]);
