(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/customerService/customerService"],{2742:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(t){},immediate:!0,deep:!0}},methods:{go:function(t){wx.navigateTo({url:t.currentTarget.dataset.url})}}};e.default=r},"96a9":function(t,e,n){"use strict";n.r(e);var r=n("ec9d"),u=n("bd4c");for(var a in u)"default"!==a&&function(t){n.d(e,t,(function(){return u[t]}))}(a);n("bf92");var c,f=n("f0c5"),o=Object(f["a"])(u["default"],r["b"],r["c"],!1,null,"4d0f0ae4",null,!1,r["a"],c);e["default"]=o.exports},bd4c:function(t,e,n){"use strict";n.r(e);var r=n("2742"),u=n.n(r);for(var a in r)"default"!==a&&function(t){n.d(e,t,(function(){return r[t]}))}(a);e["default"]=u.a},bf92:function(t,e,n){"use strict";var r=n("fdf7"),u=n.n(r);u.a},ec9d:function(t,e,n){"use strict";var r,u=function(){var t=this,e=t.$createElement;t._self._c},a=[];n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return r}))},fdf7:function(t,e,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/customerService/customerService-create-component',
    {
        'pages/index/customerService/customerService-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("96a9"))
        })
    },
    [['pages/index/customerService/customerService-create-component']]
]);
