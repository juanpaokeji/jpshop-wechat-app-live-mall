(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/fourImage/fourImage"],{"11ab":function(t,e,n){"use strict";n.r(e);var a=n("2399"),r=n("84c0");for(var u in r)"default"!==u&&function(t){n.d(e,t,(function(){return r[t]}))}(u);n("5f83");var c,o=n("f0c5"),f=Object(o["a"])(r["default"],a["b"],a["c"],!1,null,"1368c6fa",null,!1,a["a"],c);e["default"]=f.exports},2399:function(t,e,n){"use strict";var a,r=function(){var t=this,e=t.$createElement;t._self._c},u=[];n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return a}))},"5f83":function(t,e,n){"use strict";var a=n("e1b3"),r=n.n(a);r.a},"84c0":function(t,e,n){"use strict";n.r(e);var a=n("d0ee"),r=n.n(a);for(var u in a)"default"!==u&&function(t){n.d(e,t,(function(){return a[t]}))}(u);e["default"]=r.a},d0ee:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(t){},immediate:!0,deep:!0}},methods:{go:function(t){console.log(t.currentTarget.dataset.link),wx.navigateTo({url:t.currentTarget.dataset.link})}}};e.default=a},e1b3:function(t,e,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/fourImage/fourImage-create-component',
    {
        'pages/index/fourImage/fourImage-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("11ab"))
        })
    },
    [['pages/index/fourImage/fourImage-create-component']]
]);
