(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/glossary/glossary"],{"0fd5":function(t,e,n){"use strict";n.r(e);var a=n("dbea"),r=n("6e28");for(var u in r)"default"!==u&&function(t){n.d(e,t,(function(){return r[t]}))}(u);n("d409");var c,o=n("f0c5"),f=Object(o["a"])(r["default"],a["b"],a["c"],!1,null,"51cee928",null,!1,a["a"],c);e["default"]=f.exports},"6e28":function(t,e,n){"use strict";n.r(e);var a=n("93f7"),r=n.n(a);for(var u in a)"default"!==u&&function(t){n.d(e,t,(function(){return a[t]}))}(u);e["default"]=r.a},"93f7":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(t){},immediate:!0,deep:!0}},methods:{go:function(t){wx.navigateTo({url:t.currentTarget.dataset.link})}}};e.default=a},d409:function(t,e,n){"use strict";var a=n("e3bc"),r=n.n(a);r.a},dbea:function(t,e,n){"use strict";var a,r=function(){var t=this,e=t.$createElement;t._self._c},u=[];n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return a}))},e3bc:function(t,e,n){}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/glossary/glossary-create-component',
    {
        'pages/index/glossary/glossary-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("0fd5"))
        })
    },
    [['pages/index/glossary/glossary-create-component']]
]);
