(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/message/message"],{"3d36":function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(n){console.log(n)},immediate:!0,deep:!0}},methods:{sub:function(n){console.log(n)}}};t.default=a},5801:function(n,t,e){"use strict";var a=e("a5a5"),c=e.n(a);c.a},8473:function(n,t,e){"use strict";e.r(t);var a=e("3d36"),c=e.n(a);for(var u in a)"default"!==u&&function(n){e.d(t,n,(function(){return a[n]}))}(u);t["default"]=c.a},a5a5:function(n,t,e){},c3cf:function(n,t,e){"use strict";var a,c=function(){var n=this,t=n.$createElement;n._self._c},u=[];e.d(t,"b",(function(){return c})),e.d(t,"c",(function(){return u})),e.d(t,"a",(function(){return a}))},f375:function(n,t,e){"use strict";e.r(t);var a=e("c3cf"),c=e("8473");for(var u in c)"default"!==u&&function(n){e.d(t,n,(function(){return c[n]}))}(u);e("5801");var o,r=e("f0c5"),f=Object(r["a"])(c["default"],a["b"],a["c"],!1,null,"529878c0",null,!1,a["a"],o);t["default"]=f.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/message/message-create-component',
    {
        'pages/index/message/message-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("f375"))
        })
    },
    [['pages/index/message/message-create-component']]
]);
