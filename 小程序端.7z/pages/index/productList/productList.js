(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/productList/productList"],{"00f8":function(t,n,e){},3281:function(t,n,e){"use strict";e.r(n);var u=e("95b2"),a=e("44a0");for(var c in a)"default"!==c&&function(t){e.d(n,t,(function(){return a[t]}))}(c);e("c4f1");var r,o=e("f0c5"),f=Object(o["a"])(a["default"],u["b"],u["c"],!1,null,"de824666",null,!1,u["a"],r);n["default"]=f.exports},"44a0":function(t,n,e){"use strict";e.r(n);var u=e("fdd0"),a=e.n(u);for(var c in u)"default"!==c&&function(t){e.d(n,t,(function(){return u[t]}))}(c);n["default"]=a.a},"95b2":function(t,n,e){"use strict";var u,a=function(){var t=this,n=t.$createElement;t._self._c},c=[];e.d(n,"b",(function(){return a})),e.d(n,"c",(function(){return c})),e.d(n,"a",(function(){return u}))},c4f1:function(t,n,e){"use strict";var u=e("00f8"),a=e.n(u);a.a},fdd0:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(t){console.log(t)},immediate:!0,deep:!0}},methods:{}};n.default=u}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/productList/productList-create-component',
    {
        'pages/index/productList/productList-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("3281"))
        })
    },
    [['pages/index/productList/productList-create-component']]
]);
