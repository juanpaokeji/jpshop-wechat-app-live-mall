(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/richText/richText"],{"2f92":function(t,n,e){"use strict";var a,u=function(){var t=this,n=t.$createElement;t._self._c},r=[];e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return r})),e.d(n,"a",(function(){return a}))},4817:function(t,n,e){"use strict";var a=e("b558"),u=e.n(a);u.a},"6d30":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(t){console.log(t)},immediate:!0,deep:!0}},methods:{}};n.default=a},aea0:function(t,n,e){"use strict";e.r(n);var a=e("6d30"),u=e.n(a);for(var r in a)"default"!==r&&function(t){e.d(n,t,(function(){return a[t]}))}(r);n["default"]=u.a},b558:function(t,n,e){},fb98:function(t,n,e){"use strict";e.r(n);var a=e("2f92"),u=e("aea0");for(var r in u)"default"!==r&&function(t){e.d(n,t,(function(){return u[t]}))}(r);e("4817");var c,o=e("f0c5"),f=Object(o["a"])(u["default"],a["b"],a["c"],!1,null,"1e4d573d",null,!1,a["a"],c);n["default"]=f.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/richText/richText-create-component',
    {
        'pages/index/richText/richText-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("fb98"))
        })
    },
    [['pages/index/richText/richText-create-component']]
]);
