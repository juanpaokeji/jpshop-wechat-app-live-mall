(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/threeImage/threeImage"],{3591:function(e,t,n){"use strict";n.r(t);var a=n("845e"),r=n("f9a7");for(var u in r)"default"!==u&&function(e){n.d(t,e,(function(){return r[e]}))}(u);n("bfed");var o,c=n("f0c5"),f=Object(c["a"])(r["default"],a["b"],a["c"],!1,null,"eefe0882",null,!1,a["a"],o);t["default"]=f.exports},"845e":function(e,t,n){"use strict";var a,r=function(){var e=this,t=e.$createElement;e._self._c},u=[];n.d(t,"b",(function(){return r})),n.d(t,"c",(function(){return u})),n.d(t,"a",(function(){return a}))},9803:function(e,t,n){},a850:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var a={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(e){console.log(e)},immediate:!0,deep:!0}},methods:{go:function(e){console.log(e.currentTarget.dataset.link),wx.navigateTo({url:e.currentTarget.dataset.link})}}};t.default=a},bfed:function(e,t,n){"use strict";var a=n("9803"),r=n.n(a);r.a},f9a7:function(e,t,n){"use strict";n.r(t);var a=n("a850"),r=n.n(a);for(var u in a)"default"!==u&&function(e){n.d(t,e,(function(){return a[e]}))}(u);t["default"]=r.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/threeImage/threeImage-create-component',
    {
        'pages/index/threeImage/threeImage-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("3591"))
        })
    },
    [['pages/index/threeImage/threeImage-create-component']]
]);
