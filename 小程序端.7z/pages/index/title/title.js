(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/title/title"],{"5ee4":function(t,e,n){"use strict";var c=n("cbb9"),a=n.n(c);a.a},ad83:function(t,e,n){"use strict";n.r(e);var c=n("e7bf"),a=n("cc4b");for(var u in a)"default"!==u&&function(t){n.d(e,t,(function(){return a[t]}))}(u);n("5ee4");var r,o=n("f0c5"),i=Object(o["a"])(a["default"],c["b"],c["c"],!1,null,"0387550e",null,!1,c["a"],r);e["default"]=i.exports},c7ae:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var c={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(t){console.log(t)},immediate:!0,deep:!0}},methods:{}};e.default=c},cbb9:function(t,e,n){},cc4b:function(t,e,n){"use strict";n.r(e);var c=n("c7ae"),a=n.n(c);for(var u in c)"default"!==u&&function(t){n.d(e,t,(function(){return c[t]}))}(u);e["default"]=a.a},e7bf:function(t,e,n){"use strict";var c,a=function(){var t=this,e=t.$createElement;t._self._c},u=[];n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return c}))}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/title/title-create-component',
    {
        'pages/index/title/title-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("ad83"))
        })
    },
    [['pages/index/title/title-create-component']]
]);
