(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/video/video"],{"0774":function(t,e,n){"use strict";var a,u=function(){var t=this,e=t.$createElement;t._self._c},r=[];n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return r})),n.d(e,"a",(function(){return a}))},3468:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(t){console.log(t)},immediate:!0,deep:!0}},methods:{}};e.default=a},"5be9":function(t,e,n){"use strict";n.r(e);var a=n("0774"),u=n("6313");for(var r in u)"default"!==r&&function(t){n.d(e,t,(function(){return u[t]}))}(r);n("ea1b");var c,o=n("f0c5"),i=Object(o["a"])(u["default"],a["b"],a["c"],!1,null,"cb6f4a06",null,!1,a["a"],c);e["default"]=i.exports},6313:function(t,e,n){"use strict";n.r(e);var a=n("3468"),u=n.n(a);for(var r in a)"default"!==r&&function(t){n.d(e,t,(function(){return a[t]}))}(r);e["default"]=u.a},"6e7b":function(t,e,n){},ea1b:function(t,e,n){"use strict";var a=n("6e7b"),u=n.n(a);u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/video/video-create-component',
    {
        'pages/index/video/video-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("5be9"))
        })
    },
    [['pages/index/video/video-create-component']]
]);
