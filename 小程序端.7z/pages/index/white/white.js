(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/white/white"],{"0a66":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var c={data:function(){return{}},components:{},props:{data:{type:Object}},watch:{data:{handler:function(t){console.log(t)},immediate:!0,deep:!0}},methods:{}};n.default=c},"4c9d":function(t,n,e){"use strict";e.r(n);var c=e("0a66"),a=e.n(c);for(var u in c)"default"!==u&&function(t){e.d(n,t,(function(){return c[t]}))}(u);n["default"]=a.a},"790c":function(t,n,e){"use strict";var c,a=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"b",(function(){return a})),e.d(n,"c",(function(){return u})),e.d(n,"a",(function(){return c}))},"7cdb":function(t,n,e){"use strict";e.r(n);var c=e("790c"),a=e("4c9d");for(var u in a)"default"!==u&&function(t){e.d(n,t,(function(){return a[t]}))}(u);e("c046");var r,o=e("f0c5"),i=Object(o["a"])(a["default"],c["b"],c["c"],!1,null,"701ff373",null,!1,c["a"],r);n["default"]=i.exports},8573:function(t,n,e){},c046:function(t,n,e){"use strict";var c=e("8573"),a=e.n(c);a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/white/white-create-component',
    {
        'pages/index/white/white-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("7cdb"))
        })
    },
    [['pages/index/white/white-create-component']]
]);
