(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/integralMall/createOrder/goodData/goodData"],{"5d40":function(t,e,n){"use strict";var a=n("7204"),r=n.n(a);r.a},"6de5":function(t,e,n){"use strict";n.r(e);var a=n("a100"),r=n.n(a);for(var u in a)"default"!==u&&function(t){n.d(e,t,(function(){return a[t]}))}(u);e["default"]=r.a},7204:function(t,e,n){},"88e2":function(t,e,n){"use strict";n.r(e);var a=n("e28a"),r=n("6de5");for(var u in r)"default"!==u&&function(t){n.d(e,t,(function(){return r[t]}))}(u);n("5d40");var o,c=n("f0c5"),f=Object(c["a"])(r["default"],a["b"],a["c"],!1,null,"4be0226f",null,!1,a["a"],o);e["default"]=f.exports},a100:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var a={data:function(){return{}},components:{},props:{data:{type:Object}},methods:{}};e.default=a},e28a:function(t,e,n){"use strict";var a,r=function(){var t=this,e=t.$createElement;t._self._c},u=[];n.d(e,"b",(function(){return r})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return a}))}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/integralMall/createOrder/goodData/goodData-create-component',
    {
        'pages/integralMall/createOrder/goodData/goodData-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("88e2"))
        })
    },
    [['pages/integralMall/createOrder/goodData/goodData-create-component']]
]);
