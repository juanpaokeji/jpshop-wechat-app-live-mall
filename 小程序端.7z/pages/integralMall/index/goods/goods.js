(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/integralMall/index/goods/goods"],{3827:function(t,n,e){"use strict";var r,o=function(){var t=this,n=t.$createElement;t._self._c},u=[];e.d(n,"b",(function(){return o})),e.d(n,"c",(function(){return u})),e.d(n,"a",(function(){return r}))},"3dd3":function(t,n,e){},4193:function(t,n,e){"use strict";var r=e("3dd3"),o=e.n(r);o.a},6512:function(t,n,e){"use strict";e.r(n);var r=e("3827"),o=e("becc");for(var u in o)"default"!==u&&function(t){e.d(n,t,(function(){return o[t]}))}(u);e("4193");var a,c=e("f0c5"),i=Object(c["a"])(o["default"],r["b"],r["c"],!1,null,"63531593",null,!1,r["a"],a);n["default"]=i.exports},becc:function(t,n,e){"use strict";e.r(n);var r=e("bf50"),o=e.n(r);for(var u in r)"default"!==u&&function(t){e.d(n,t,(function(){return r[t]}))}(u);n["default"]=o.a},bf50:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={data:function(){return{}},components:{},props:{goods:{type:Array,default:function(){return[]}},background:{type:String}},methods:{go:function(t){wx.navigateTo({url:"/pages/integralMall/goodsItem/goodsItem?id=".concat(t.currentTarget.dataset.id)})}}};n.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/integralMall/index/goods/goods-create-component',
    {
        'pages/integralMall/index/goods/goods-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("6512"))
        })
    },
    [['pages/integralMall/index/goods/goods-create-component']]
]);
