(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/orderItem/orderItemGoods/orderItemGoods"],{2681:function(t,e,n){"use strict";n.r(e);var r=n("788e"),u=n.n(r);for(var o in r)"default"!==o&&function(t){n.d(e,t,(function(){return r[t]}))}(o);e["default"]=u.a},"43ce":function(t,e,n){},"6d01":function(t,e,n){"use strict";var r,u=function(){var t=this,e=t.$createElement;t._self._c},o=[];n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return o})),n.d(e,"a",(function(){return r}))},"788e":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={data:function(){return{}},computed:{statusfmt:function(){var t={0:"待付款",1:"买家已付款",2:"订单已超时",3:"卖家已发货",6:"评价订单",7:"订单已完成"};return t[this.status]}},components:{},props:{goodsData:{type:Object},status:{type:Number}},watch:{goodsData:{handler:function(t){},immediate:!0,deep:!0}},methods:{}};e.default=r},"8fca":function(t,e,n){"use strict";n.r(e);var r=n("6d01"),u=n("2681");for(var o in u)"default"!==o&&function(t){n.d(e,t,(function(){return u[t]}))}(o);n("d101");var a,c=n("f0c5"),d=Object(c["a"])(u["default"],r["b"],r["c"],!1,null,"18b40f66",null,!1,r["a"],a);e["default"]=d.exports},d101:function(t,e,n){"use strict";var r=n("43ce"),u=n.n(r);u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/orderItem/orderItemGoods/orderItemGoods-create-component',
    {
        'pages/orderItem/orderItemGoods/orderItemGoods-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("8fca"))
        })
    },
    [['pages/orderItem/orderItemGoods/orderItemGoods-create-component']]
]);
