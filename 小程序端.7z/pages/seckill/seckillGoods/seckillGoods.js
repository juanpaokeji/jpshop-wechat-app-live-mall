(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/seckill/seckillGoods/seckillGoods"],{"567d":function(t,n,e){"use strict";var o,u=function(){var t=this,n=t.$createElement;t._self._c},a=[];e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return a})),e.d(n,"a",(function(){return o}))},"64bf":function(t,n,e){"use strict";var o=e("70fb"),u=e.n(o);u.a},"70fb":function(t,n,e){},afc2:function(t,n,e){"use strict";e.r(n);var o=e("b077d"),u=e.n(o);for(var a in o)"default"!==a&&function(t){e.d(n,t,(function(){return o[t]}))}(a);n["default"]=u.a},b077d:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o={data:function(){return{}},components:{},props:{data:{type:Array,default:function(){return[]}}},methods:{go:function(t){wx.navigateTo({url:"/pages/goodsItem/goodsItem/goodsItem?id=".concat(t.currentTarget.dataset.id)})}}};n.default=o},cb4f:function(t,n,e){"use strict";e.r(n);var o=e("567d"),u=e("afc2");for(var a in u)"default"!==a&&function(t){e.d(n,t,(function(){return u[t]}))}(a);e("64bf");var r,c=e("f0c5"),f=Object(c["a"])(u["default"],o["b"],o["c"],!1,null,"3f7219f3",null,!1,o["a"],r);n["default"]=f.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/seckill/seckillGoods/seckillGoods-create-component',
    {
        'pages/seckill/seckillGoods/seckillGoods-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("cb4f"))
        })
    },
    [['pages/seckill/seckillGoods/seckillGoods-create-component']]
]);
