(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["promoter/promotercommissionwater/Header/Header"],{"943b":function(t,e,n){"use strict";n.r(e);var r=n("b544"),a=n("c75a");for(var u in a)"default"!==u&&function(t){n.d(e,t,(function(){return a[t]}))}(u);n("ff77");var c,o=n("f0c5"),f=Object(o["a"])(a["default"],r["b"],r["c"],!1,null,"78f95423",null,!1,r["a"],c);e["default"]=f.exports},b544:function(t,e,n){"use strict";var r,a=function(){var t=this,e=t.$createElement;t._self._c},u=[];n.d(e,"b",(function(){return a})),n.d(e,"c",(function(){return u})),n.d(e,"a",(function(){return r}))},c75a:function(t,e,n){"use strict";n.r(e);var r=n("ddc0"),a=n.n(r);for(var u in r)"default"!==u&&function(t){n.d(e,t,(function(){return r[t]}))}(u);e["default"]=a.a},ddc0:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={data:function(){return{menu:[{text:"佣金流水",type:0},{text:"提现流水",type:1}]}},components:{},props:{selectIndex:{type:Number,default:0}},methods:{changeIndex:function(t){console.log(t.currentTarget.dataset.index),this.$emit("changeList",{detail:{index:t.currentTarget.dataset.index}})}}};e.default=r},f811:function(t,e,n){},ff77:function(t,e,n){"use strict";var r=n("f811"),a=n.n(r);a.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'promoter/promotercommissionwater/Header/Header-create-component',
    {
        'promoter/promotercommissionwater/Header/Header-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("943b"))
        })
    },
    [['promoter/promotercommissionwater/Header/Header-create-component']]
]);
