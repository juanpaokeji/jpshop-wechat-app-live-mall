(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["superuser/userinfosales/GroupSalesData/GroupSalesData"],{"108e":function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var r={data:function(){return{}},components:{},props:{total_price:{type:null},total_number:{type:Number},time:{type:String},list:{type:Array}},methods:{}};e.default=r},4850:function(t,e,n){"use strict";var r,u=function(){var t=this,e=t.$createElement;t._self._c},a=[];n.d(e,"b",(function(){return u})),n.d(e,"c",(function(){return a})),n.d(e,"a",(function(){return r}))},"6e5d":function(t,e,n){"use strict";n.r(e);var r=n("4850"),u=n("d43d");for(var a in u)"default"!==a&&function(t){n.d(e,t,(function(){return u[t]}))}(a);n("79a2");var o,c=n("f0c5"),i=Object(c["a"])(u["default"],r["b"],r["c"],!1,null,"09741420",null,!1,r["a"],o);e["default"]=i.exports},"79a2":function(t,e,n){"use strict";var r=n("800d"),u=n.n(r);u.a},"800d":function(t,e,n){},d43d:function(t,e,n){"use strict";n.r(e);var r=n("108e"),u=n.n(r);for(var a in r)"default"!==a&&function(t){n.d(e,t,(function(){return r[t]}))}(a);e["default"]=u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'superuser/userinfosales/GroupSalesData/GroupSalesData-create-component',
    {
        'superuser/userinfosales/GroupSalesData/GroupSalesData-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("6e5d"))
        })
    },
    [['superuser/userinfosales/GroupSalesData/GroupSalesData-create-component']]
]);
